package Ariq.platform.navdrawer

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Kesehatan : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_kesehatan)
    }
}